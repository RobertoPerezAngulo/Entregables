from setuptools import setup

setup(
    name='miPrimerPaquete',
    version='1.0',
    packages=['miPrimerPaquete'],
    author='Jose Roberto Pérez Angulo',
    author_email='jrobertoperezangulo_ipn@hotmail.com',
    description='Segunda entrega de proyecto de programacion'
)
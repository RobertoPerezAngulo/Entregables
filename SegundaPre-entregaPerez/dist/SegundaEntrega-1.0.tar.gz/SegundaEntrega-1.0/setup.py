from setuptools import setup

setup(
    name='SegundaEntrega',
    version='1.0',
    packages=[''],
    url='',
    license='',
    author='Jose Roberto',
    author_email='jrobertoperezangulo_ipn@hotmail.com',
    description='Segunda entrega de proyecto de programacion'
)